﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GTA;
using GTA.Native;
using System.Windows.Forms;
using Microsoft.Win32;
using System.IO;

namespace Disabler
{
    public class Class1 : Script
    {
        static bool isOnline;
        static string gtaDirectory = System.IO.Directory.GetCurrentDirectory().ToString();
        static string disabled = gtaDirectory + "/disabled/";

        static string scriptHookVDLL = gtaDirectory + "/ScriptHookV.dll";
        static string scriptHookVDotNetDLL = gtaDirectory + "/ScriptHookVDotNet.dll";
        static string scriptHookVDotNetASI = gtaDirectory + "/ScriptHookVDotNet.asi";
        static string scriptHookVASILoader = gtaDirectory + "/dinput8.dll";

        bool disabledExists = System.IO.Directory.Exists(disabled);
        bool scriptHookVDLLExists = File.Exists(scriptHookVDLL);
        bool scriptHookVDotNetDLLExists = File.Exists(scriptHookVDotNetDLL);
        bool scriptHookVDotNetASIExists = File.Exists(scriptHookVDotNetASI);
        bool scriptHookVASILoaderExists = File.Exists(scriptHookVASILoader);

        static int runOnce = 0;
        static int disableCheck = 0;
        public Class1()
        {
            Tick += onTick;
            KeyDown += onKeyDown;
        }

        void onTick(object sender, EventArgs e)
        {
            if (disableCheck == 0)
            {
                if (!disabledExists)
                    System.IO.Directory.CreateDirectory(disabled);
                disableCheck++;
            }
            isOnline = GTA.Native.Function.Call<bool>(GTA.Native.Hash.IS_PLAYER_ONLINE);
            if (isOnline)
            {
                if (runOnce == 0)
                {
                    runOnce++;
                    if (scriptHookVDLLExists)
                    {
                        File.Copy(scriptHookVDLL, disabled);
                        File.Delete(scriptHookVDLL);
                    }
                    if (scriptHookVASILoaderExists)
                    {
                        File.Copy(scriptHookVASILoader, disabled);
                        File.Delete(scriptHookVASILoader);
                    }
                    if (scriptHookVDotNetDLLExists)
                    {
                        File.Copy(scriptHookVDotNetDLL, disabled);
                        File.Delete(scriptHookVDotNetDLL);
                    }
                    if (scriptHookVDotNetASIExists)
                    {
                        File.Copy(scriptHookVDotNetASI, disabled);
                        File.Delete(scriptHookVDotNetASI);
                    }
                }
            }
        }
        void onKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Q:
                    UI.ShowSubtitle("ScriptHookV: " + scriptHookVDLLExists.ToString() + "; " + "ScriptHookVLoader: " + scriptHookVASILoaderExists.ToString() + "; " + "ScriptHookVDotNet: " + scriptHookVDotNetDLLExists.ToString() + "; " + "ScriptHookVDotNetASI: " + scriptHookVDotNetASIExists.ToString() + ";" + "Folder: " + disabledExists.ToString() + ";");
                    break;
            }
        }
    }
}
