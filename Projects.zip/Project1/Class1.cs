﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GTA;
using GTA.Native;

namespace BTTF
{
    class Class1 : Script
    {
        string space = GTA.Native.Function.Call<string>(GTA.Native.Hash.GET_VEHICLE_PED_IS_IN).ToLower();
        int speed = GTA.Native.Function.Call<int>(GTA.Native.Hash.GET_VEHICLE_ACCELERATION);
        int h = GTA.Native.Function.Call<int>(GTA.Native.Hash.GET_CLOCK_HOURS);
        int m = GTA.Native.Function.Call<int>(GTA.Native.Hash.GET_CLOCK_MINUTES);
        public Class1()
        {
            Tick += OnTick;
        }

        void OnTick(object sender, EventArgs e)
        {
            if (space == "dune2")
            {
                if (speed == 20)
                {
                    GTA.Native.Function.Call(GTA.Native.Hash.SET_CLOCK_TIME, h+1, m, 0);
                }
            }
        }
    }
}
