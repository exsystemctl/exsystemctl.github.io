#pragma once
class script
{
public:
	script(void);
	~script(void);
};

