﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            File.Create("test.txt");
            Thread.Sleep(200);
            Directory.CreateDirectory(System.IO.Directory.GetCurrentDirectory() + "/disabled");
            using (var inputFile = new FileStream("test.txt", FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var outputFile = new FileStream(System.IO.Directory.GetCurrentDirectory() + "/disabled/test.txt", FileMode.Create))
                {
                    var buffer = new byte[0x10000];
                    int bytes;

                    while ((bytes = inputFile.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        outputFile.Write(buffer, 0, bytes);
                    }
                }
            }
        }
    }
}

