﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Emmanuel.Cryptography.GnuPG;
using System.IO;
using Org.BouncyCastle;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Generators;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Math;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Bcpg;
using Org.BouncyCastle.Bcpg.OpenPgp;
using System.Windows.Forms;
using System.Collections;
using System.Security.Permissions;
using ICSharpCode.SharpZipLib;

namespace sysCrypt
{
    class Program
    {
        static string publicKey = "";
        static string privateKey = "";
        private PgpEncryptionKeys m_encryptionKeys;

        private PgpSignatureGenerator InitSignatureGenerator(Stream compressedOut)
        {

            const bool IsCritical = false;

            const bool IsNested = false;

            PublicKeyAlgorithmTag tag = m_encryptionKeys.SecretKey.PublicKey.Algorithm;

            PgpSignatureGenerator pgpSignatureGenerator =

                new PgpSignatureGenerator(tag, HashAlgorithmTag.Sha1);

            pgpSignatureGenerator.InitSign(PgpSignature.BinaryDocument, m_encryptionKeys.PrivateKey);

            foreach (string userId in m_encryptionKeys.SecretKey.PublicKey.GetUserIds())
            {

                PgpSignatureSubpacketGenerator subPacketGenerator =
                   new PgpSignatureSubpacketGenerator();

                subPacketGenerator.SetSignerUserId(IsCritical, userId);

                pgpSignatureGenerator.SetHashedSubpackets(subPacketGenerator.Generate());

                // Just the first one!

                break;

            }

            pgpSignatureGenerator.GenerateOnePassVersion(IsNested).Encode(compressedOut);

            return pgpSignatureGenerator;

        }

        public static string ReadPassword()
        {
            string password = "";
            ConsoleKeyInfo info = Console.ReadKey(true);
            while (info.Key != ConsoleKey.Enter)
            {
                if (info.Key != ConsoleKey.Backspace)
                {
                    Console.Write("*");
                    password += info.KeyChar;
                }
                else if (info.Key == ConsoleKey.Backspace)
                {
                    if (!string.IsNullOrEmpty(password))
                    {
                        // remove one character from the list of password characters
                        password = password.Substring(0, password.Length - 1);
                        // get the location of the cursor
                        int pos = Console.CursorLeft;
                        // move the cursor to the left by one character
                        Console.SetCursorPosition(pos - 1, Console.CursorTop);
                        // replace it with space
                        Console.Write(" ");
                        // move the cursor to the left by one character again
                        Console.SetCursorPosition(pos - 1, Console.CursorTop);
                    }
                }
                info = Console.ReadKey(true);
            }
            Console.WriteLine();
            return password;
        }

        public class ConsoleSpiner
        {
            int counter;
            public ConsoleSpiner()
            {
                counter = 0;
            }
            public void Turn()
            {
                counter++;
                switch (counter % 4)
                {
                    case 0: Console.Write("/"); break;
                    case 1: Console.Write("-"); break;
                    case 2: Console.Write("\\"); break;
                    case 3: Console.Write("|"); break;
                }
                Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
            }
        }

        public static void GenerateKey(string username, string password, string keyStoreUrl)
        {
            IAsymmetricCipherKeyPairGenerator kpg = new RsaKeyPairGenerator();
            kpg.Init(new RsaKeyGenerationParameters(BigInteger.ValueOf(0x13), new SecureRandom(), 1024, 8));
            AsymmetricCipherKeyPair kp = kpg.GenerateKeyPair();
            FileStream out1 = new FileInfo(string.Format("{0}/secret.asc", keyStoreUrl)).OpenWrite();
            FileStream out2 = new FileInfo(string.Format("{0}/pub.asc", keyStoreUrl)).OpenWrite();
            ExportKeyPair(out1, out2, kp.Public, kp.Private, username, password.ToCharArray(), true);
            out1.Close();
            out2.Close();
        }

        private static void ExportKeyPair(Stream secretOut, Stream publicOut, AsymmetricKeyParameter publicKey, AsymmetricKeyParameter privateKey, string identity, char[] passPhrase, bool armor)
        {
            if (armor)
            {
                secretOut = new ArmoredOutputStream(secretOut);
            }
            PgpSecretKey secretKey = new PgpSecretKey(PgpSignature.DefaultCertification, PublicKeyAlgorithmTag.RsaGeneral, publicKey, privateKey, DateTime.Now, identity, SymmetricKeyAlgorithmTag.Cast5, passPhrase, null, null, new SecureRandom());
            secretKey.Encode(secretOut);
            secretOut.Close();
            if (armor)
            {
                publicOut = new ArmoredOutputStream(publicOut);
            }
            PgpPublicKey key = secretKey.PublicKey;
            key.Encode(publicOut);
            publicOut.Close();
        }

        static string homePage = "1 : Generate PGP Public Key\n2 : Locate Keys\n3 : Encrypt String\n4 : Encrypt File\n5 : Sign and Encrypt String\n6 : Sign and Encrypt File\n7 : Sign File\n8 : Verify String\n9 : Verify File";
        
        [STAThread]
        static void Main(string[] args)
        {
            Start:
            Console.WriteLine(homePage);
            string choice = Console.ReadLine();
            switch (choice)
            {
                case "1":
                    Console.Clear();
            Username:
                    Console.WriteLine("Please enter a username/alias");
                    string username = Console.ReadLine();
                    Console.Clear();
            Correct:
                    Console.WriteLine("(Y/N) Please verify your username, this will be locked to your public key: " + username);
                    string isUsernameCorrect = Console.ReadLine().ToLower();
                    switch (isUsernameCorrect)
                    {
                        case "y":
                            Console.Clear();
                            break;
                        case "n":
                            Console.WriteLine("Alrighty, not a problem, going back a few steps...");
                            Thread.Sleep(2000);
                            Console.Clear();
                            goto Username;
                        default:
                            Console.WriteLine("That's not an option! Going back to username verification...");
                            Thread.Sleep(2000);
                            Console.Clear();
                            goto Correct;
                    }
            Passphrase:
                    Console.WriteLine("Ok, " + username + ", please enter a passphrase");
                    string pass = ReadPassword();
                    Console.Clear();
                    Console.WriteLine("Please retype your passphrase...");
                    string verifyPassword = ReadPassword();
                    Console.Clear();

                    if (pass == verifyPassword)
                    {
                        Console.WriteLine("Password verified. Locate where you would like your public/private keys to be placed...");
                        string keyPath = "";
                        FolderBrowserDialog folderBrowserDialog1 = new FolderBrowserDialog();
                        if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                        {
                            keyPath = folderBrowserDialog1.SelectedPath;
                        }
                        Console.Clear();
                        Console.WriteLine("Keys will be located at " + keyPath + ". You can change this later.");
                        Thread.Sleep(2000);
                        Console.Clear();
                        ConsoleSpiner spin = new ConsoleSpiner();
                        Console.WriteLine("Generating....");
                        GenerateKey(username, pass, keyPath);
                        int i = 0;
                        while (i < 5000)
                        {
                            spin.Turn();
                            i++;
                        }
                        Console.Clear();
                        Console.WriteLine("Done! Returning to homepage, " + username);
                        Thread.Sleep(2000);
                        Console.Clear();
                        goto Start;
                    }
                    else
                    {
                        Console.WriteLine("The passwords you typed did not match, going back a few steps...");
                        Thread.Sleep(2000);
                        Console.Clear();
                        goto Passphrase;
                    }
                    break;
                case "2":
                    break;
                case "3":
                    Console.Clear();

                    break;
                case "4":
                    break;
                case "5":
                    break;
                case "6":
                    break;
                case "7":
                    break;
                case "8":
                    break;
                case "9":
                    break;
                default:
                    Console.WriteLine("That's not an option! Going back home...");
                    Thread.Sleep(500);
                    Console.Clear();
                    goto Start;
            }
        }
    }
}
