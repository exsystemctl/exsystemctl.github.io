﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PluginContracts;
using System.Windows;

namespace Commands
{
    public class CommandPlugin : IPlugin
    {
        public string Name
        {
            get
            {
                return "First Plugin";
            }
        }

        public void Do()
        {
            MessageBox.Show("Do Something in First Plugin");
        } 
    }
}
