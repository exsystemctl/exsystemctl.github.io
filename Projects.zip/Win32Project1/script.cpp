#include "script.h"

#include <string>

Player player = PLAYER::PLAYER_ID();
Ped playerPed = PLAYER::PLAYER_PED_ID();
Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(playerPed);
char* carname = (char *)(LPCSTR)VEHICLE::GET_DISPLAY_NAME_FROM_VEHICLE_MODEL(ENTITY::GET_ENTITY_MODEL(veh));

void update_status_text()
{
		UI::SET_TEXT_FONT(0);
		UI::SET_TEXT_SCALE(0.55, 0.55);
		UI::SET_TEXT_COLOUR(255, 255, 255, 255);
		UI::SET_TEXT_WRAP(0.0, 1.0);
		UI::SET_TEXT_CENTRE(1);
		UI::SET_TEXT_DROPSHADOW(0, 0, 0, 0, 0);
		UI::SET_TEXT_EDGE(1, 0, 0, 0, 205);
		UI::_SET_TEXT_ENTRY(carname);
		UI::_DRAW_TEXT(0.5, 0.5);
	}

void startLoop(){
while(!PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0))
{
	update_status_text();
}
}
