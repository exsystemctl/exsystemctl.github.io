﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace RPG
{
    public class SpriteSheetEffect : ImageEffect
    {
        public int FrameCounter;
        public int SwitchFrame;
        public Vector2 currentFrame;
        public Vector2 amountOfFrames;
        public int FrameWidth
        {
            get
            {
                if (image.Texture != null)
                    return image.Texture.Width / (int)amountOfFrames.X;
                return 0;
            }
        }

        public int FrameHeight
        {
            get
            {
                if (image.Texture != null)
                    return image.Texture.Height / (int)amountOfFrames.Y;
                return 0;
            }
        }
        public SpriteSheetEffect()
        {
            amountOfFrames = new Vector2(3, 4);
            currentFrame = new Vector2(1, 0);
            SwitchFrame = 100;
            FrameCounter = 0;
        }

        public override void LoadContent(ref Image Image)
        {
            base.LoadContent(ref Image);
        }

        public override void UnloadContent()
        {
            base.UnloadContent();
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            if (image.IsActive)
            {
                FrameCounter += (int)gameTime.ElapsedGameTime.TotalMilliseconds;
                if (FrameCounter >= SwitchFrame)
                {
                    FrameCounter = 0;
                    currentFrame.X++;

                    if (currentFrame.X * FrameWidth >= image.Texture.Width)
                        currentFrame.X = 0;

                }
            }
            else
                currentFrame.X = 1;

            image.SourceRect = new Rectangle((int)currentFrame.X * FrameWidth,
                (int)currentFrame.Y * FrameHeight, FrameWidth, FrameHeight);
        }
    }
}
