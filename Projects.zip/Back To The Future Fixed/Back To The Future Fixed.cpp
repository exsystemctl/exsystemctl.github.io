// Back To The Future Fixed.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"

#include "script.h"

Ped playerPed = PLAYER::PLAYER_PED_ID();
Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(playerPed);
