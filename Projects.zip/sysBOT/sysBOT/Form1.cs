﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Windows;
using System.Threading;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Reflection;
using Microsoft.Win32;
using Microsoft.VisualBasic;

namespace sysBOT
{

    public partial class Form1 : Form
    {
        public static string command;
        public static string response;
        public static string fullCommand;
        public static string removeCommand;
        public static string SERVER = "asimov.freenode.net";
        private static int PORT = 6667;
        private static string USER = "USER systemCTL-Bot 0 * :systemCTL-Bot";
        private static string NICK = "systemCTL-Bot";
        private static string PASS = "Heflindinger!90210";
        private static string CHANNEL = "#sysCHAT";
        private static string version = "build e1427910624";
        public static StreamWriter writer;
        public static bool commandExists;
        public static string text;
        public static string file = @"C:\Documents\Visual Studio 2012\Projects\sysBOT\commands.bot";
        public static List<string> commands = File.ReadAllLines(file).ToList();
        public static List<string> mods = new List<string>();
        public static string tempCommand;
        public static bool isMod;

        public Form1()
        {
            InitializeComponent();
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            new Thread(() =>
            {
                Thread.CurrentThread.IsBackground = true;
                sysBOT();
            }).Start();
        }

        public static void writeConsole(string sender, string command, bool error)
        {
            if (error == true)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Command \"" + command + "\" from " + sender + " returned an error.");
                Console.ResetColor();
            }
            else if (error == false)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Command \"" + command + "\" from " + sender);
                Console.ResetColor();
            }
        }

        public static void sysBOT()
        {

            System.Threading.Thread.Sleep(3000);
            //LOAD: read/write/irc
            NetworkStream stream;
            TcpClient irc;
            string inputLine;
            StreamReader reader;
            try
            {

                irc = new TcpClient(SERVER, PORT);
                stream = irc.GetStream();
                reader = new StreamReader(stream);
                writer = new StreamWriter(stream);
                writer.WriteLine("PASS " + PASS);
                writer.WriteLine("NICK " + NICK);
                writer.Flush();
                writer.WriteLine(USER);
                writer.Flush();
                while (true)
                {
                    while ((inputLine = reader.ReadLine()) != null)
                    {

                        Console.WriteLine("<-" + inputLine);
                        string[] splitInput = inputLine.Split(new Char[] { ' ' });
                        string output = inputLine.Substring(inputLine.IndexOf("&") + 1);
                        string[] str = output.Split(' ');

                        if (splitInput[0] == "PING")
                        {
                            string PongReply = splitInput[1];
                            writer.WriteLine("PONG " + PongReply);
                            writer.Flush();
                            continue;
                        }

                        switch (splitInput[1])
                        {
                            case "001":
                                string JoinString = "JOIN " + CHANNEL;
                                writer.WriteLine(JoinString);
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("sysBot Connected!");
                                Thread.Sleep(3000);
                                Console.WriteLine("Module \"writeConsole\" loaded!");
                                Thread.Sleep(632);
                                Console.WriteLine("Module \"pluginManager\" loaded!");
                                Thread.Sleep(925);
                                Console.WriteLine("Module \"autoReply\" loaded!");
                                Thread.Sleep(462);
                                Console.WriteLine("Module \"dynamicRW\" loaded!");
                                Thread.Sleep(873);
                                Console.WriteLine("All modules loaded successfully!");
                                Console.ResetColor();
                                Thread.Sleep(3000);
                                writer.Flush();
                                break;
                            default:
                                break;
                        }
                        if (output != null)
                        {
                            //TODO: Begin
                            //TODO: +---------------------------------------------------------------------+
                            //TODO: |  Revamp console writing via a huge void  |   <------------DONE------------>
                            //TODO: +---------------------------------------------------------------------+
                            //TODO: |                Add mod-only support                 |   <--------------WIP-------------->
                            //TODO: +---------------------------------------------------------------------+
                            //TODO: |                 Make a cleaner GUI                    |   <-------FUCK THAT------->
                            //TODO: +---------------------------------------------------------------------+
                            //TODO: End

                            //for more commands after initial, put str[1], str[2], etc...
                            if (str[0] == "steam")
                            {
                                string commandSender = inputLine.Split(new char[] { ':', '!' })[1];
                                //Begin Console Writing
                                writeConsole(commandSender, str[0], false);
                                //End Console Writing
                                writer.WriteLine("PRIVMSG #sysCHAT:Add me on steam! http://steamcommunity.com/id/girlbrony69");
                                writer.Flush();
                            }
                            else if (str[0] == "slap")
                            {
                                if (2 > str.Length)
                                {
                                    string commandSender = inputLine.Split(new char[] { ':', '!' })[1];
                                    //Begin Console Writing
                                    writeConsole(commandSender, str[0], true);
                                    //End Console Writing
                                    writer.WriteLine("PRIVMSG #sysCHAT :You need to specify who to slap!");
                                    writer.Flush();
                                }
                                else
                                {
                                    string commandSender = inputLine.Split(new char[] { ':', '!' })[1];
                                    //Begin Console Writing
                                    writeConsole(commandSender, str[0], false);
                                    //End Console Writing
                                    writer.WriteLine("PRIVMSG #sysCHAT :" + commandSender + " has slapped " + str[1] + "!");
                                    writer.Flush();
                                }
                            }
                            else if (str[0] == "info")
                            {
                                string commandSender = inputLine.Split(new char[] { ':', '!' })[1];
                                //Begin Console Writing
                                writeConsole(commandSender, str[0], false);
                                //End Console Writing
                                writer.WriteLine("PRIVMSG #sysCHAT :sysBOT :: " + version);
                                writer.Flush();
                            }
                            else if (inputLine.Contains("JOIN"))
                            {
                                string commandSender = inputLine.Split(new char[] { ':', '!' })[1];
                                //Begin Console Writing
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine(commandSender + " has joined!");
                                Console.ResetColor();
                                //End Console Writing
                                writer.WriteLine("PRIVMSG #sysCHAT :Welcome, " + commandSender);
                                writer.Flush();
                            }
                            else if (inputLine.Contains("PART"))
                            {
                                string commandSender = inputLine.Split(new char[] { ':', '!' })[1];
                                //Begin Console Writing
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine(commandSender + " has left :<");
                                Console.ResetColor();
                                //End Console Writing
                            }
                            else if (str[0] == "mod")
                            {
                                string commandSender = inputLine.Split(new char[] { ':', '!' })[1].ToLower();
                                foreach (string mod in mods.ToList())
                                {
                                    if (commandSender == mod)
                                    {
                                        //Begin Console Writing
                                        writeConsole(commandSender, str[0], false);
                                        //End Console Writing
                                        writer.WriteLine("PRIVMSG #sysCHAT :" + commandSender + " is a mod!");
                                        writer.Flush();
                                        isMod = true;
                                        break;
                                    }
                                    isMod = false;
                                }
                                if (isMod == false)
                                {
                                    //Begin Console Writing
                                    writeConsole(commandSender, str[0], true);
                                    //End Console Writing
                                    writer.WriteLine("PRIVMSG #sysCHAT :" + commandSender + " is not a mod!");
                                    writer.Flush();
                                }
                            }
                            else if (commands != null)
                            {
                                foreach (string cmd in commands)
                                {
                                    string command = cmd.Substring(0, cmd.IndexOf(':'));
                                    string response = cmd.Substring(cmd.IndexOf(":") + 1);
                                    if (str[0] == command)
                                    {
                                        string commandSender = inputLine.Split(new char[] { ':', '!' })[1];
                                        //Begin Console Writing
                                        writeConsole(commandSender, command, false);
                                        //End Console Writing
                                        writer.WriteLine("PRIVMSG #sysCHAT :" + response);
                                        writer.Flush();
                                    }
                                }
                            }
                        }
                    }
                    writer.Close();
                    reader.Close();
                    irc.Close();
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                Thread.Sleep(5000);
                string[] argv = { };

            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            command = Interaction.InputBox("Input command", "Add commands", "");
            response = Interaction.InputBox("Input response", "Add commands", "");
            fullCommand = command + ":" + response;
            commands.Add(fullCommand);
            using (System.IO.StreamWriter writeCommand = new System.IO.StreamWriter(file, true))
            {
                writeCommand.WriteLine(fullCommand);
            }
            //Begin Console Writing
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Command \"" + command + "\" registered.");
            Console.ResetColor();
            //End Console Writing
        }

        private void button2_Click(object sender, EventArgs e)
        {
            removeCommand = Interaction.InputBox("Which command would you like to remove?", "Remove commands", "");
            foreach (string cmd in commands.ToList())
            {
                string command = cmd.Substring(0, cmd.IndexOf(':'));
                if (command == removeCommand)
                {
                    tempCommand = cmd;
                    commands.Remove(cmd);
                    string tempFile = Path.GetTempFileName();

                    using (var sr = new StreamReader(file))
                    using (var sw = new StreamWriter(tempFile))
                    {
                        string line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            //if the line does not equal cmd (command:response), then re-write it to the file.
                            if (line != tempCommand)
                                sw.WriteLine(line);
                        }
                    }
                    File.Delete(file);
                    File.Move(tempFile, file);
                    //Begin Console Writing
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Command \"" + removeCommand + "\" removed.");
                    Console.ResetColor();
                    //End Console Writing
                    commandExists = true;
                    break;
                }
                else
                {
                    commandExists = false;
                }
            }
            if (commandExists == false)
            {
                //Begin Console Writing
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Command \"" + removeCommand + "\" does not exist.");
                Console.ResetColor();
                //End Console Writing
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            DialogResult result = openFileDialog1.ShowDialog();
            openFileDialog1.Filter = "sysBOT Files|*.bot";
            openFileDialog1.Title = "Select a sysBOT File";
            file = openFileDialog1.FileName;
            if (result == DialogResult.OK)
            {
                // text = File.ReadAllText(file);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Command file loaded from \"" + file + "\"");
                Console.ResetColor();
                string[] lines = System.IO.File.ReadAllLines(file);
                foreach (string line in lines)
                {
                    string command = line.Substring(0, line.IndexOf(':'));
                    //Begin Console Writing
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Command \"" + command + "\" loaded.");
                    Console.ResetColor();
                    //End Console Writing
                }
            }
        }
    }
}