﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Evolutionator
{
    class Program
    {
        static void Main(string[] args)
        {
            int targetNum;
            List<int> num = new List<int>();
            Random random = new Random();
            Console.WriteLine("I am going to randomly generate a number from 1 to 100");
            Thread.Sleep(2000);
            targetNum = random.Next(1, 100);
            Console.WriteLine("Your target number is " + targetNum);
            Thread.Sleep(2000);
            Console.WriteLine("Now I will generate 100 random numbers between 1 and 100");
            Thread.Sleep(2000);
            int y = 0;
            while (y != 100)
            {
                y++;
                int randomNum = random.Next(1, 100);
                num.Add(randomNum);
                Console.WriteLine(randomNum);
                Thread.Sleep(50);
            }
            Console.Clear();
            Console.WriteLine("All of these numbers have been stored, and are being compared with the target number.");
            Thread.Sleep(2000);
            Console.WriteLine("The 50 numbers that are the furthest away from the target number will be elminated.");
            Thread.Sleep(2000);
            Console.WriteLine("Another 50 numbers will be generated that are similar to the remaining 50, bring the total back to 100.");
            Thread.Sleep(2000);
            num.Sort();
        }
    }
}
