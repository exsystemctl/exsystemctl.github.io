﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GTA;
using GTA.Native;
using System.Windows.Forms;

namespace Exigent
{
    public class Class1 : Script
    {
        int i = 0;
        static int playerNum;
        static Entity entity;
        public Class1()
        {
            Tick += onTick;
            KeyDown += onKeyDown;
        }

        public void onTick(object sender, EventArgs e)
        {
            playerNum = GTA.Native.Function.Call<int>(GTA.Native.Hash.GET_NUMBER_OF_PLAYERS);
            if (i < playerNum)
            {
                entity = GTA.Native.Function.Call<Entity>(GTA.Native.Hash.GET_PLAYER_PED, i);
                GTA.Native.Function.Call(GTA.Native.Hash.ADD_BLIP_FOR_ENTITY, entity);
                GTA.Native.Function.Call(GTA.Native.Hash.SET_BLIP_COLOUR, i, 0);
                i++;
            }
            else if (i > playerNum)
            {
                GTA.Native.Function.Call(GTA.Native.Hash.SET_BLIP_SPRITE, i, 69);
                i--;
            }
        }

        public void onKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F4:
                    break;
            }
        }
    }
}
