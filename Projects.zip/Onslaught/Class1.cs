﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GTA;
using GTA.Native;

namespace Onslaught
{
    public class Class1 : Script
    {
        bool runOnce = false;
        string[] test = {"1", "2", "3"};
        static bool gotMilk;
        public Class1()
        {
            //Tick += onTick;
            KeyDown += onKeyDown;
        }
        void onTick(object sender, EventArgs e)
        {
            //GTA.Native.Function.Call(Hash.SET_PED_NON_CREATION_AREA, -999999, -999999, -999999, 999999, 999999, 999999); that din work
            Ped playerPed = Game.Player.Character;
 
            GTA.Native.Function.Call(Hash.SET_NUMBER_OF_PARKED_VEHICLES, 0);
            GTA.Native.Function.Call(Hash.SET_VEHICLE_DENSITY_MULTIPLIER_THIS_FRAME, 0.0);
            GTA.Native.Function.Call(Hash.SET_PED_DENSITY_MULTIPLIER_THIS_FRAME, 0.0);
            gotMilk = GTA.Native.Function.Call<bool>(Hash.HAS_PED_GOT_WEAPON, playerPed, 0x9D61E50F, true);

            if (gotMilk)
            {
                UI.ShowSubtitle("You have the bullpup big one gun");
            }
            else if (!gotMilk)
            {
                UI.ShowSubtitle("no gun u ded");
            }
            if (!runOnce)
            {
                GTA.Native.Function.Call(Hash.REMOVE_ALL_PED_WEAPONS, playerPed, 1);
                runOnce = true;
            }
        }
        void onKeyDown(object sender, KeyEventArgs e)
        {
            switch(e.KeyCode)
            {
                case Keys.F6:
                    Tick += onTick;
                    break;
                default:
                     break;
            }
        }
    }
}
