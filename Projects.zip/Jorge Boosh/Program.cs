﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Management;
using System.Text.RegularExpressions;
using System.Reflection;

namespace Raw_Power
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            string resource1 = "Raw_Power.NAudio.dll";
            string resource2 = "Raw_Power.NAudio.WindowsMediaFormat.dll";
            EmbeddedAssembly.Load(resource1, "NAudio.dll");
            EmbeddedAssembly.Load(resource2, "NAudio.WindowsMediaFormat.dll");
            AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(CurrentDomain_AssemblyResolve);

            WebClient sfjh = new WebClient();
            Stream stream = sfjh.OpenRead("https://www.dropbox.com/s/dbqcw34ndsxtjzu/hwid.json?dl=1");
            StreamReader reader = new StreamReader(stream);
            String temp = reader.ReadToEnd();
            sfjh.Dispose();
            var mbs = new ManagementObjectSearcher("Select ProcessorId From Win32_processor");
            ManagementObjectCollection mbsList = mbs.Get();
            string id = "";
            foreach (ManagementObject mo in mbsList)
            {
                id = mo["ProcessorId"].ToString();
                break;
            }

            Regex g = new Regex(id);
            string line;
            while ((line = temp.ToString()) != null)
            {
                Match hwidMatch = g.Match(line);
                if (hwidMatch.Success)
                {
                        Application.Run(new MainForm());
                        return;
                }
                else
                {
                        Application.Run(new Form1());
                        return;
                }
            }      
        }

        static Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
        {
            return EmbeddedAssembly.Get(args.Name);
        }
    }
}
