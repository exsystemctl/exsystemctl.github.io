﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NAudio;
using System.IO;
using System.Net;
using NAudio.Wave;
using System.Threading;
using System.Security.Permissions;

namespace Raw_Power
{
    public partial class MainForm : Form
    {
        public static WaveOut waveOut = new WaveOut(WaveCallbackInfo.FunctionCallback());
        public static Stream ms = new MemoryStream();
        public  CheckBox playpause { get { return checkBox1; } }
          static string[] music = new string[] { 
            "https://a.pomf.se/cewxhx.mp3", 
            "https://www.dropbox.com/s/90jczapiqn285lw/02%20-%20Warm%20Power.mp3?dl=1", 
            "https://www.dropbox.com/s/1rq1ibh19hkn0bd/03%20-%20Star%20Power.mp3?dl=1", 
            "https://www.dropbox.com/s/n9rzl3sgc2mpmcd/04%20-%20Blooming%20Power.mp3?dl=1",
            "https://www.dropbox.com/s/m0l1hxku7mj9c78/05%20-%20Thinning%20Power.mp3?dl=1",
            "https://www.dropbox.com/s/eqqvt17ourdh8bs/06%20-%20Need%20Power.mp3?dl=1",
            "https://www.dropbox.com/s/9ssjueuisb10mzo/07%20-%20High%20on%20Power.mp3?dl=1",
            "https://www.dropbox.com/s/78cqxy2cuurclyi/08%20-%20Close%20Power.mp3?dl=1",
            "https://www.dropbox.com/s/ynmiyghdn9zb7lf/09%20-%20Changing%20Power.mp3?dl=1",
            "https://www.dropbox.com/s/jkimyeh3avxe94d/10%20-%20Centralized%20Power.mp3?dl=1",
            "https://www.dropbox.com/s/21g8nfze2f0j41a/11%20-%20Always%20Power.mp3?dl=1",
            "https://www.dropbox.com/s/yshm0phfcgghn1g/12%20-%20Cyclical%20Power.mp3?dl=1",
            "https://www.dropbox.com/s/ew7gkvsxc9873og/13%20-%20Tropic%20Power.mp3?dl=1",
            "https://www.dropbox.com/s/5y6oawmj8a06loa/14%20-%20African%20Power.mp3?dl=1",
            "https://www.dropbox.com/s/2cj36j1agvv1qyc/15%20-%20Goodbye%20Power.mp3?dl=1"};

        public static string[] names = new string[] { 
            "Insane Power", 
            "Warm Power", 
            "Star Power", 
            "Blooming Power",
            "Thinning Power",
            "Need Power",
            "High on Power",
            "Close Power",
            "Changing Power",
            "Centralized Power",
            "Always Power",
            "Cyclical Power",
            "Tropic Power",
            "African Power",
            "Goodbye Power"};

        public static int songNum = 0;
        public static int position;
        public static int begin = 1;
        public MainForm()
        {
            InitializeComponent();
            start(0);
        }
        public static Thread playing;
        public void start(int song)
        {
                 playing = new Thread(o =>
                {
                    play(music[song]);
                });
                playing.Start();
        }
        public void startLoop()
        {
            if (begin == 1)
            {
                begin++;
                start(0);
                System.Threading.Thread.Sleep(100);
                startLoop();
            }
            else
            {
                while (waveOut.PlaybackState == PlaybackState.Playing)
                {
                    System.Threading.Thread.Sleep(100);
                }
                songNum++;
                if (songNum > 14)
                    songNum = 0;
                playing.Abort();
                start(songNum);
            }
        }
        
         public void play(string url)
        {
                using (Stream stream = WebRequest.Create(url)
                    .GetResponse().GetResponseStream())
                {
                    byte[] buffer = new byte[32768];
                    int read;
                    while ((read = stream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        ms.Write(buffer, 0, read);
                    }
                }

                ms.Position = 0;
                using (WaveStream blockAlignedStream =
                    new BlockAlignReductionStream(
                        WaveFormatConversionStream.CreatePcmStream(
                            new Mp3FileReader(ms))))
                {
                    waveOut.Init(blockAlignedStream);
                    waveOut.Play();
                    while (waveOut.PlaybackState == PlaybackState.Playing)
                    {
                        System.Threading.Thread.Sleep(100);
                    }
                }
        }

        public  void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
        }
        [SecurityPermissionAttribute(SecurityAction.Demand, ControlThread = true)]
        private void button3_Click(object sender, EventArgs e)
        {
            //Next
            playing.Abort();
            songNum++;
            if (songNum > 14)
                songNum = 0;

            while (waveOut.PlaybackState == PlaybackState.Playing)
                System.Threading.Thread.Sleep(100);
            start(songNum);
            label2.Text = names[songNum];
        }
        [SecurityPermissionAttribute(SecurityAction.Demand, ControlThread = true)]
        private void button4_Click(object sender, EventArgs e)
        {
            //Previous
            playing.Abort();
            songNum--;
            if (songNum < 0)
                songNum = 14;

            start(songNum);
            label2.Text = names[songNum];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }
    }
}
