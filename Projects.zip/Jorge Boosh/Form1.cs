﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.Mail;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Raw_Power
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            WebClient sfjh = new WebClient();
            Stream stream = sfjh.OpenRead("https://www.dropbox.com/s/6thfmvqy3fgfk0d/code.json?dl=1");
            StreamReader reader = new StreamReader(stream);
            String temp = reader.ReadToEnd();
            sfjh.Dispose();
            var mbs = new ManagementObjectSearcher("Select ProcessorId From Win32_processor");
            ManagementObjectCollection mbsList = mbs.Get();
            string id = "";
            foreach (ManagementObject mo in mbsList)
            {
                id = mo["ProcessorId"].ToString();
                break;
            }
            string code = textBox1.Text;
            string activated = code + "_1";
            Regex g = new Regex(code);
            Regex f = new Regex(activated);
            string line;
            while ((line = temp.ToString()) != null)
            {
                Match codeMatch = g.Match(line);
                Match activatedCode = f.Match(line);
                if (activatedCode.Success)
                {
                    MessageBox.Show("This code has already been activated.");
                    this.Close();
                    return;
                }
                else if (codeMatch.Success)
                {
                    MessageBox.Show("Awaiting confirmation from Jorge Boosh. Please re-run the program in 30-50 minutes. If your code is still not confirmed, remind him at school.");
                    //runMain();

                    var fromAddress = new MailAddress("jorgebooshactivation@gmail.com");
                    var toAddress = new MailAddress("jckgriggs@gmail.com");
                    string fromPassword = "OuXe-2&amp;hGgaR*r8eodO@+47y4Pw&amp;zv";
                    string subject = "Confirm HWID";
                    string body = "Code: " + code + "; HWID: " + id;

                    var smtp = new SmtpClient
                    {
                        Host = "smtp.gmail.com",
                        Port = 25,
                        EnableSsl = true,
                        DeliveryMethod = SmtpDeliveryMethod.Network,
                        UseDefaultCredentials = false,
                        Credentials = new NetworkCredential(fromAddress.Address, fromPassword)
                    };
                    using (var message = new MailMessage(fromAddress, toAddress)
                    {
                        Subject = subject,
                        Body = body
                    })
                    {
                        smtp.Send(message);
                    }

                    this.Close();
                    return;

                }
                else
                {
                    MessageBox.Show("Invalid code.");
                    return;
                }
            }
        }
    }
}
