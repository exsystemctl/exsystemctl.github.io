﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GTA;
using GTA.Native;
using System.Windows.Forms;
using System.Threading;

namespace modet
{
    public class Class1 : Script
    {
        int player = Game.Player.ID;
        //int model = GTA.Native.Function.Call<int>(GTA.Native.Hash.GET_HASH_KEY, "u_m_y_zombie_01");
        static bool hasModelLoaded;
        static bool hasPlayerLoaded;
        static bool isValid;
        static bool checkValid;
        static bool checkModel;
        static bool checkPlayer;
        static bool toggle = false;
        public Class1()
        {
            Tick += onTick;
            KeyDown += onKeyDown;
        }

        void onTick(object sender, EventArgs e)
        {
            if (checkModel)
                hasModelLoaded = GTA.Native.Function.Call<bool>(GTA.Native.Hash.HAS_MODEL_LOADED, model);
            if(checkPlayer)
                hasPlayerLoaded = GTA.Native.Function.Call<bool>(GTA.Native.Hash.HAS_MODEL_LOADED, player);
            if (checkValid)
                isValid = GTA.Native.Function.Call<bool>(GTA.Native.Hash.IS_MODEL_VALID, 0xAC4B4506);
        }
        void onKeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Q:
                    if (!toggle)
                    {
                        checkValid = true;
                        if (!isValid)
                        {
                            UI.ShowSubtitle(0xAC4B4506 + " is invalid");
                            checkValid = false;
                        }
                        else
                        {
                            checkModel = true;
                            GTA.Native.Function.Call(GTA.Native.Hash.REQUEST_MODEL, 0xAC4B4506);
                            while (!hasModelLoaded)
                                Thread.Sleep(0);
                            checkModel = false;
                            GTA.Native.Function.Call(GTA.Native.Hash.SET_PLAYER_MODEL, Game.Player.ID, 0xAC4B4506);
                            GTA.Native.Function.Call(GTA.Native.Hash.SET_MODEL_AS_NO_LONGER_NEEDED, 0xAC4B4506);
                            toggle = true;
                        }
                    }
                    else if (toggle)
                    {
                        checkModel = true;
                        GTA.Native.Function.Call(GTA.Native.Hash.REQUEST_MODEL, player);
                        while (!hasPlayerLoaded)
                            Thread.Sleep(0);
                        checkPlayer = false;
                        GTA.Native.Function.Call(GTA.Native.Hash.SET_PLAYER_MODEL, 0xAC4B4506, player);
                        GTA.Native.Function.Call(GTA.Native.Hash.SET_MODEL_AS_NO_LONGER_NEEDED, player);
                        toggle = false;
                    }
                    break;
            }
        }
    }
}
