﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;
using Replicon.Cryptography.SCrypt;
using System.Security.Cryptography;
using Scrypt;
using System.Collections.Specialized;

namespace KeybaseGUI
{
    public partial class Form1 : Form
    {
        static string salt;
        static string csrf_token;
        static string login_session;
        static byte[] pwh;
        static string hmac_pwh;
        static string ByteToString(byte[] buff)
        {
            string sbinary = "";
            for (int i = 0; i < buff.Length; i++)
                sbinary += buff[i].ToString("X2"); /* hex format */
            return sbinary;
        }
        public Form1()
        {
            InitializeComponent();
        }

        public string hex2Bin(string strHex)
        {
            int decNumber = hex2Dec(strHex);
            return dec2Bin(decNumber);
        }
        public string bin2Hex(string strBin)
        {
            int decNumber = bin2Dec(strBin);
            return dec2Hex(decNumber);
        }

        private string dec2Hex(int val)
        {
            return val.ToString("X");
            //return Convert.ToString(val,16);
        }

        private int hex2Dec(string strHex)
        {
            return Convert.ToInt16(strHex, 16);
        }
        private string dec2Bin(int val)
        {
            return Convert.ToString(val, 2);
        }
        public int bin2Dec(string strBin)
        {
            return Convert.ToInt16(strBin, 2);
        }
        static byte[] GetBytes(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void usernameTextBox_TextChanged(object sender, EventArgs e)
        {

        }
        private void passwordTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
        
            //Get Login Session and prepare hmac_pwh
            HttpWebRequest login = (HttpWebRequest)WebRequest.Create("https://keybase.io/_/api/1.0/getsalt.json");
            ASCIIEncoding encoding = new ASCIIEncoding();
            string postData = "email_or_username=" + usernameTextBox.Text;
            byte[] data = encoding.GetBytes(postData);
            login.Method = "POST";
            login.ContentType = "application/x-www-form-urlencoded";
            login.ContentLength = data.Length;
            using (Stream stream = login.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }
            HttpWebResponse response = (HttpWebResponse)login.GetResponse();
            string responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
            login.Abort();
            //MessageBox.Show(responseString);
            JObject joResponse = JObject.Parse(responseString) ;
            salt = (string)joResponse["salt"];
            csrf_token = (string)joResponse["csrf_token"];
            login_session = (string)joResponse["login_session"];
            byte[] passwordBytes = GetBytes(passwordTextBox.Text);
            byte[] saltBytes = GetBytes(salt);

            pwh = SCrypt.DeriveKey(passwordBytes, saltBytes, 32768, 8, 1, 224);
            pwh = pwh.Skip(192).ToArray();
            using (var hmacsha512 = new HMACSHA512(pwh))
            {
                hmacsha512.ComputeHash(encoding.GetBytes(Convert.FromBase64String(login_session).ToString()));
                hmac_pwh = ByteToString(hmacsha512.Hash);
            }



            //Finally login omg
            HttpWebRequest loginReq = (HttpWebRequest)WebRequest.Create("https://keybase.io/_/api/1.0/login.json");
            ASCIIEncoding encoding1 = new ASCIIEncoding();
            string postData1 = "email_or_username=" + usernameTextBox.Text;
            postData1 += "&hmac_pwh=" + hmac_pwh.ToString();
            postData1 += "&login_session=" + login_session;
            byte[] data1 = encoding1.GetBytes(postData1);
            loginReq.Method = "POST";
            loginReq.ContentType = "application/x-www-form-urlencoded";
            loginReq.ContentLength = data1.Length;
            using (Stream stream1 = loginReq.GetRequestStream())
            {
                stream1.Write(data1, 0, data1.Length);
            }
            HttpWebResponse response1 = (HttpWebResponse)loginReq.GetResponse();
            string responseString1 = new StreamReader(response1.GetResponseStream()).ReadToEnd();
            loginReq.Abort();
            MessageBox.Show(responseString1); //Get error codes and such, remove this later though
        }
    }
}