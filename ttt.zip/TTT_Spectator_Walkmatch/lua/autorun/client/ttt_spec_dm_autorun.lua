
SpecDM = {}

include("cl_spectator_deathmatch.lua")